/*
 * CreateDB Class - Connects to DB, builds table, populates data
* And queries DB for object values needed for driver class.
 */
package brickblocks;

import java.sql.*;
import java.util.ArrayList;

/**
 * Create DB method - connect to DB, create table and records. 
 */
public class CreateDB 
{
    public static void main(String[] args)
    {
        // Named constant for URL
        final String URL = "jdbc:derby:BrickBlocks;create = true";
        
        try
        {
            // Create connector
            Connection conn = DriverManager.getConnection(URL);
        
            // Drop tables if exists
            dropTables(conn);
        
            // Build Table
            buildTable(conn);
            
            // Query Table
            getName(conn);
            getLength(conn);
            getHeight(conn);
            getWidth(conn);
            getPrice(conn);
            
        
            // Close connection to DB
            conn.close();
        }
        catch (Exception ex)
        {
            System.out.println("Error: " + ex.getMessage());
        }    
}

/**
 * Drop tables Method - drops table if any data exists
 */
public static void dropTables(Connection conn)
{
    System.out.println("Checking for existing tables.");
    
    try
   {
        // Get statement object
        Statement stmt = conn.createStatement();
        
        try
       {
            // Drop table
            stmt.execute("DROP TABLE OBJECTS");
            System.out.println("Objects table dropped");
       }
       catch(SQLException ex)
      {
            //Table Dropped 
       }
   }
   
    catch(SQLException ex)
  {
      System.out.println("ERROR: " + ex.getMessage());
  }        
  
}

/**
 * Build table method - Create table and populate with necessary data.
 */

public static void buildTable(Connection conn)
{
    try
    {
        // Get statement object
        Statement stmt = conn.createStatement();
        
        // Create table
        stmt.execute("CREATE TABLE OBJECTS (ID INT NOT NULL PRIMARY KEY, NAME VARCHAR(30),"
                    + "LENGTH DOUBLE, HEIGHT DOUBLE, WIDTH DOUBLE, PRICE DOUBLE)");
        
        // Add records
        stmt.execute("INSERT INTO OBJECTS VALUES(1, 'StandardBrick', 8.000, 2.625, 4.000, "
                    + "0.539)");
        stmt.executeUpdate("INSERT INTO OBJECTS VALUES(2, 'FancyBrick', 8.000, 2.625, 4.000, "
                    + "0.809)");
        stmt.executeUpdate("INSERT INTO OBJECTS VALUES(4, 'ArchHead', 122.000, 22.000, 22.000, "
                    + "350.000)");
        stmt.executeUpdate("INSERT INTO OBJECTS VALUES(5, 'DentilCornice', 24.000, 24.000, 1.000, "
                    + "40.000)");
        stmt.executeUpdate("INSERT INTO OBJECTS VALUES(6, 'VoidSpace', 135.000, 98.000, 20.000, 0.000)");      
    }
    catch (SQLException ex)
      {
         System.out.println("ERROR: " + ex.getMessage());
      }
}

/**
 * getName method - Query Name and create arraylist to store values
 */
public static ArrayList<String> getName(Connection conn) throws SQLException
{
    // Get statement object
    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
        ResultSet.CONCUR_READ_ONLY);
    
    // Execute Query
    ResultSet res = stmt.executeQuery("Select Name FROM Objects");
    
    // Get # of rows
    res.last();                 // Move to last row
    int numRows = res.getRow(); // Get row number
    res.first();                // Move to first row
    
    // Create arraylist for object names
    ArrayList<String> listData = new ArrayList<>();
    
    // Populate the array.
      for (int index = 0; index < numRows; index++)
      {
         // Add record to array
         listData.add(res.getString(1));

         // Go to the next row
         res.next();
      }
          
              
    //Return Name
    return listData;
}

/**
 * getLength method - Query Length and create arraylist to store values
 */
public static ArrayList<Double> getLength(Connection conn) throws SQLException
{
    // Get statement object
    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
        ResultSet.CONCUR_READ_ONLY);
    
    // Execute Query
    ResultSet res = stmt.executeQuery("Select Length FROM Objects");
    
    // Get # of rows
    res.last();                 // Move to last row
    int numRows = res.getRow(); // Get row number
    res.first();                // Move to first row
    
    // Create arraylist for object names
    ArrayList<Double> listData = new ArrayList<>();
    
    // Populate the array.
      for (int index = 0; index < numRows; index++)
      {
         // Add record to array
         listData.add(res.getDouble(1));

         // Go to the next row
         res.next();
      }
    
    //Return Name
    return listData;
}

/**
 * getHeight method - Query Height and create arraylist to store values
 */
public static ArrayList<Double> getHeight(Connection conn) throws SQLException
{
    // Get statement object
    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
        ResultSet.CONCUR_READ_ONLY);
    
    // Execute Query
    ResultSet res = stmt.executeQuery("Select Height FROM Objects");
    
    // Get # of rows
    res.last();                 // Move to last row
    int numRows = res.getRow(); // Get row number
    res.first();                // Move to first row
    
    // Create arraylist for object names
    ArrayList<Double> listData = new ArrayList<>();
    
    // Populate the array.
      for (int index = 0; index < numRows; index++)
      {
         // Add record to array
         listData.add(res.getDouble(1));

         // Go to the next row
         res.next();
      }
              
    //Return Name
    return listData;
}

/**
 * getWidth method - Query Width and create arraylist to store values
 */
public static ArrayList<Double> getWidth(Connection conn) throws SQLException
{
    // Get statement object
    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
        ResultSet.CONCUR_READ_ONLY);
    
    // Execute Query
    ResultSet res = stmt.executeQuery("Select Width FROM Objects");
    
    // Get # of rows
    res.last();                 // Move to last row
    int numRows = res.getRow(); // Get row number
    res.first();                // Move to first row
    
    // Create arraylist for object names
    ArrayList<Double> listData = new ArrayList<>();
    
    // Populate the array.
      for (int index = 0; index < numRows; index++)
      {
         // Add record to array
         listData.add(res.getDouble(1));

         // Go to the next row
         res.next();
      }
              
    //Return Name
    return listData;
}

/**
 * getPrice method - Query Price and create arraylist to store values
 */
public static ArrayList<Double> getPrice(Connection conn) throws SQLException
{
    // Get statement object
    Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
        ResultSet.CONCUR_READ_ONLY);
    
    // Execute Query
    ResultSet res = stmt.executeQuery("Select Price FROM Objects");
    
    // Get # of rows
    res.last();                 // Move to last row
    int numRows = res.getRow(); // Get row number
    res.first();                // Move to first row
    
    // Create arraylist for object names
    ArrayList<Double> listData = new ArrayList<>();
    
    // Populate the array.
      for (int index = 0; index < numRows; index++)
      {
         // Add record to array
         listData.add(res.getDouble(1));

         // Go to the next row
         res.next();
      }             
        
    //Return Name
    return listData;
}

    static class getName {

        public getName() {
        }
    }

}

