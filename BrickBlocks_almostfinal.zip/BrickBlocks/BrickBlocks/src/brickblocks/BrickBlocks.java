/*
 * Group 5 (Brandon Dalton, Chris Noyes, Jeffrey Ochs, Kyler Kershaw)
 * Date Started: 11/10/19
 * Date Finished: 12/10/19
 * CSC-251-0001
 * This project calculates the cost and materials needed for building a facade
 */
package brickblocks;
// imports
import javax.swing.JOptionPane;
import java.text.NumberFormat;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class BrickBlocks {

    public static void main(String[] args) throws SQLException {
        
        
        // DB URL
        final String URL = "jdbc:derby:BrickBlocks;create = true";
        // Connect to DB
        Connection conn = DriverManager.getConnection(URL);
        /** 
         * GET NAMES FROM THE DB
         */
        // Create an empty arrayList        
        ArrayList<String> listDataName = new ArrayList<>();
        // Pull the data from the db  and assign them to the previous arrayList
        listDataName = CreateDB.getName(conn);
        // Pull the data off the list and assign the name variables.
        String brick = listDataName.get(0);
        String fancyBrick = listDataName.get(1);
        String archHead = listDataName.get(2);
        String dentilCornice = listDataName.get(3);
        String voidSpace = listDataName.get(4);
        /**
         * GET ITEM LENGTH FROM DB
         */        
        ArrayList<Double> listDataLength = new ArrayList<>();
        listDataLength = CreateDB.getLength(conn);
        double brickLength = listDataLength.get(0);
        double fancyBrickLength = listDataLength.get(1);
        double archHeadLength = listDataLength.get(2);
        double dentilCorniceLength = listDataLength.get(3);
        double voidSpaceLength = listDataLength.get(4);
        /**
         * GET ITEM HEIGHT FROM DB
         */        
        ArrayList<Double> listDataHeight = new ArrayList<>();
        listDataHeight = CreateDB.getHeight(conn);
        double brickHeight = listDataHeight.get(0);
        double fancyBrickHeight = listDataHeight.get(1);
        double archHeadHeight = listDataHeight.get(2);
        double dentilCorniceHeight = listDataHeight.get(3);
        double voidSpaceHeight = listDataHeight.get(4);
        /**
         * GET ITEM WIDTH FROM DB
         */
        ArrayList<Double> listDataWidth = new ArrayList<>();
        listDataWidth = CreateDB.getWidth(conn);
        double brickWidth = listDataWidth.get(0);
        double fancyBrickWidth = listDataWidth.get(1);
        double archHeadWidth = listDataWidth.get(2);
        double dentilCorniceWidth = listDataWidth.get(3);
        double voidSpaceWidth = listDataWidth.get(4);
        /**
         * GET PRICES FROM DB
         */
        ArrayList<Double> listDataPrice = new ArrayList<>();
        listDataPrice = CreateDB.getPrice(conn);
        double brickPrice = listDataPrice.get(0);
        double fancyBrickPrice = listDataPrice.get(1);
        double archHeadPrice = listDataPrice.get(2);
        double dentilCornicePrice = listDataPrice.get(3);
        double voidSpacePrice = listDataPrice.get(4);
        
        /** 
         * Main Menu Code
         */
        String[] selection={"Yes", "No"};
        String[] brickChoice={"Fancy", "Regular"};
        // Asking for arches
        int choice1 = JOptionPane.showOptionDialog(null,"Would you like "
                + "arches on your wall?","Choose an option",
                JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE,
                null,selection,selection[0]);
        
        // Asking for brick patterns
        int choice2 = JOptionPane.showOptionDialog(null,"Would you like "
                + "brick patterns on your wall?","Choose an option",
                JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE,
                null,selection,selection[0]); 
        
        
        // Asking the type of brick
        int choice3 = JOptionPane.showOptionDialog(null,"What kind of brick  "
                + "would you like?","Choose an option",
                JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE,
                null,brickChoice,brickChoice[0]);
        
        
        if (choice3 == 0){
            brickPrice = fancyBrickPrice;
        }
        
        // Calculations for testing purposes to check functionallity 
        // ******PLEASE CHANGE TO HEARTS DESIRE*******
        int bricksNeeded = calculateBricksNeeded(choice1, choice2, choice3, 
                brickHeight, brickLength, voidSpaceHeight,
                voidSpaceLength);
        int cementNeeded = calculateCementNeeded(bricksNeeded);
        double brickCost = calculateBrickCost(bricksNeeded, brickPrice);
        double cementCost = calculateCementCost(cementNeeded);
        double archCost = calculateArchCost(archHeadPrice);
        double corniceNeeded = calculateCorniceNeeded (dentilCorniceLength);
        double corniceCost = calculateCorniceCost(corniceNeeded,dentilCornicePrice);
        
        // Total cost calculation, changes with if statement based on choices.
        double totalCost = totalCostCalculation(choice1, choice2, brickCost, cementCost, archCost, corniceCost);
        
        NumberFormat fmt = NumberFormat.getCurrencyInstance();        
        
        JFrameProject(bricksNeeded, cementNeeded, brickCost, cementCost, archCost, totalCost, choice1, choice2, choice3, fmt);
        
    }
    
    // Calculations method for bricks needed, basis for most of the other calculations    
    public static int calculateBricksNeeded(int choice1, 
            int choice2, int choice3, double brickHeight, 
            double brickLength, double voidSpaceHeight, double voidSpaceLength)
            throws SQLException{

        
        //bricks needed after rounding    
        int bricksNeeded;
        //6 sections of wall at 55ft per section, left it like this because 
        //we weren't sure about number of sections
        double wallLength=55.0*6.0;
        double wallHeight=26.0;
        //square footage of the wall
        double wallSquare=0;
        //number of layers deep the wall will be
        double wallWidth=4.0;
        //square footage of the brick
        double brickSquare=0;
        //bricks needed before rounding
        double totalBrick=0;
        //square footage of the voidspace
        double voidSpaceSquare=0;
        //total number of bricks to subtract for each voidspace
        double voidSpaceBrick=0;
        
        String patternSelected;        
        String brickSelection;
        
        // choice 1 = Arches?                       0=Y 1=N
        // choice 2 = Brick Patterns                0=Y 1=N
        // choice 3 = Choices applied to side wrap? 0=Y 1=N
        // choice 4 = Brick choice?                 0=Fancy 1=Regular
        
        // Choice 1
        if (choice1 == 1){           
            voidSpaceLength = 0.0;
            voidSpaceHeight = 0.0;
        }
        
        // Choice 2
        if (choice2 == 0){
            patternSelected = "\nPattern selected: Yes";
        }
        else{
            patternSelected = "\nPattern selected: No";
        }
        
        // Choice 3
        if (choice3==0){
            brickSelection = "\nBrick type selected: Fancy\n";
            
        }
        else{
            brickSelection = "\nBrick type Selected: Regular\n";
        }
        //calculating the square footage of the wall
        wallSquare = wallLength*wallHeight;
        //calculating the sqaure footage of the brick
        brickSquare = ((brickLength+.375)*(brickHeight+.375))/144.0;
        //calculating the square footage of the void space
        voidSpaceSquare = (voidSpaceLength/12.0)*(voidSpaceHeight/12.0);
        //calculating the amount of bricks per void space prior to depth
        voidSpaceBrick = voidSpaceSquare/brickSquare;
        //calculating the amount of bricks per void space with depth
        voidSpaceBrick = voidSpaceBrick*wallWidth;
        //calculating total number of void spaces per section (2)
        //and number of sections (6) to get total amount of void space to subtract
        voidSpaceBrick = voidSpaceBrick*2.0*6.0;
        //calculating overall amount of bricks needed prior to depth
        totalBrick = wallSquare/brickSquare;
        //calculating overall amount of bricks needed prior to depth
        totalBrick = totalBrick * wallWidth;
        //calculating overall bricks after removing void space for arches
        totalBrick = totalBrick-voidSpaceBrick;
        //adding a 10% overage for number of bricks
        totalBrick = totalBrick * 1.10;
        //rounding up to the nearest brick
        totalBrick = Math.ceil(totalBrick);
        //converting to an integer data type
        bricksNeeded = (int) totalBrick;
        
        System.out.print(patternSelected);        
        System.out.print(brickSelection);
        return bricksNeeded;
        
    }
    //this method calculates bags of cement/mortar needed based on number of bricks
    public static int calculateCementNeeded (int bricksNeeded){
        int cementNeeded= (bricksNeeded)/142; 
        
        return cementNeeded;
    }
    //this method calculates number of cornices needed
    public static double calculateCorniceNeeded (double corniceLength){
        int wallLength = 55*6;
        double corniceNeeded = Math.ceil(wallLength/corniceLength);
        
        return corniceNeeded;
    }
    //this method calculates the cost of bricks per pallet rounded to the nearest pallet
    public static double calculateBrickCost (int bricksNeeded, double brickPrice){
        double brickPallet= Math.ceil(bricksNeeded/510.0);
        double brickCost = 510*brickPrice;
        brickCost= brickCost*brickPallet;       
        
        return brickCost;
    }
    
    //this method calculates the cost of cement/mortar per pallet rounded to the nearest pallet
    public static double calculateCementCost (int cementNeeded){
        double cementPallet= cementNeeded/35.0;
        double cementCost =cementPallet*500.0;        
        
        return cementCost;
    }
    //this method calculates the cost of arches for the entire wall
    public static double calculateArchCost(double archHeadPrice){
        double archNeeded = 6*2;
        double archCost = archNeeded * archHeadPrice;
        
        return archCost;
    }
    //this method calculates the cost of the cornices for the entire wall
    public static double calculateCorniceCost (double corniceNeeded, double cornicePrice){
        double corniceCost = corniceNeeded * cornicePrice;
        
        return corniceCost;
    }
        
    //this method calculates the total cost of all materials and choices
    public static double totalCostCalculation(int choice1, int choice2, double brickCost, double cementCost, double archCost, double corniceCost){
        double totalCost;
        if(choice1 == 1){
            if(choice2 == 0){
                totalCost = brickCost + cementCost + (brickCost * .05) + corniceCost;
            }
            else{
                totalCost = brickCost + cementCost + corniceCost;
            }
        }
        else{
            if(choice2 == 0){
                totalCost = brickCost + cementCost + archCost + (brickCost * .05) + corniceCost;
            }
            else{
                totalCost = brickCost + cementCost + archCost + corniceCost;
            }
        }
        return totalCost;
    }
    //this method creates a custom JFrame to allow for a better designed invoice
    public static void JFrameProject(int bricksNeeded, int cementNeeded, double brickCost, 
            double cementCost, double archCost, double totalCost, int choice1, int choice2, int choice3, NumberFormat fmt) 
    {
        // Created a new JFramed with label instances for design
        JFrame newJFrame = new JFrame();
        JLabel jLabel1 = new JLabel();
        JLabel jLabel2 = new JLabel();
        JLabel jLabel3 = new JLabel();
        JLabel jLabel4 = new JLabel();
        JLabel jLabel5 = new JLabel();
        JLabel jLabel6 = new JLabel();
        JLabel jLabel7 = new JLabel();
        JLabel jLabel8 = new JLabel();
        JLabel jLabel9 = new JLabel();
        JLabel jLabel11 = new JLabel();
        JLabel jLabel10 = new JLabel();
        JLabel jLabel13 = new JLabel();
        JLabel jLabel14 = new JLabel();
        JLabel jLabel15 = new JLabel();
        JLabel jLabel16 = new JLabel();
        JLabel jLabel17 = new JLabel();
        JLabel jLabel19 = new JLabel();
        JLabel jLabel20 = new JLabel();
        JLabel jLabel21 = new JLabel();
        JLabel jLabel22 = new JLabel();
        JLabel jLabel23 = new JLabel();
        JLabel jLabel24 = new JLabel();
        JLabel jLabel25 = new JLabel();
        
        // exits the program instead of being caught in it till manually closed.
        newJFrame.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        newJFrame.getContentPane().setLayout(null);
        
        // Custom labels that change or are static based on user input
        //label for date of order
        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel4.setText("DEC 12, 2019");
        newJFrame.getContentPane().add(jLabel4);
        jLabel4.setBounds(750, 130, 120, 20);
        //label for pay period
        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel5.setText("DEC 15, 2019");
        newJFrame.getContentPane().add(jLabel5);
        jLabel5.setBounds(620, 200, 120, 20);
        //label for consumer
        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 16));
        jLabel2.setText("Mr. Teter");
        newJFrame.getContentPane().add(jLabel2);
        jLabel2.setBounds(50, 200, 70, 30);
        //displays whether the bricks are fancy or regular
        if(choice3 == 1)
        {
            jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14));
            jLabel14.setText("REGULAR BRICKS");
            newJFrame.getContentPane().add(jLabel14);
            jLabel14.setBounds(20, 310, 150, 20);
        }
        else
        {
            jLabel14.setFont(new java.awt.Font("Tahoma", 0, 14));
            jLabel14.setText("FANCY BRICKS");
            newJFrame.getContentPane().add(jLabel14);
            jLabel14.setBounds(20, 310, 150, 20);
        }
        //label for brick details
        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel8.setText(Integer.toString(bricksNeeded/510) + " Pallets of Bricks. (510 bricks per pallet)");
        newJFrame.getContentPane().add(jLabel8);
        jLabel8.setBounds(240, 310, 510, 20);
        //label for brick cost
        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel13.setText(fmt.format(brickCost));
        newJFrame.getContentPane().add(jLabel13);
        jLabel13.setBounds(780, 310, 90, 20);
        //label for cement text
        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel15.setText("MORTAR");
        newJFrame.getContentPane().add(jLabel15);
        jLabel15.setBounds(20, 330, 90, 20);
        //label for cement details
        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel9.setText(Integer.toString(cementNeeded) + " bags of mortar.");
        newJFrame.getContentPane().add(jLabel9);
        jLabel9.setBounds(240, 330, 500, 20);
        //label for cement cost
        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        jLabel3.setText(fmt.format(cementCost));
        newJFrame.getContentPane().add(jLabel3);
        jLabel3.setBounds(780, 330, 90, 20);
        //displays if archs are choosen by the user
        if(choice1 == 0)
        {
            //label for arch text
            jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14));
            jLabel16.setText("ARCH DESIGN");
            newJFrame.getContentPane().add(jLabel16);
            jLabel16.setBounds(20, 350, 90, 20);
            //label for arch details
            jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14));
            jLabel10.setText("12 archs for the wall based");
            newJFrame.getContentPane().add(jLabel10);
            jLabel10.setBounds(240, 350, 520, 20);
            //label for arch cost
            jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14));
            jLabel6.setText(fmt.format(archCost));
            newJFrame.getContentPane().add(jLabel6);
            jLabel6.setBounds(780, 350, 90, 20);
        }
        //label for time and labor text
        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel17.setText("Time & Labor");
        newJFrame.getContentPane().add(jLabel17);
        jLabel17.setBounds(20, 370, 90, 20);
        //label for time and labor details
        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel11.setText("2 Months + $45 per hour");
        newJFrame.getContentPane().add(jLabel11);
        jLabel11.setBounds(240, 370, 510, 20);
        //label for time and labor cost
        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel19.setText(fmt.format(40*8*45));
        newJFrame.getContentPane().add(jLabel19);
        jLabel19.setBounds(780, 370, 90, 20);
        //displays if the user had patterns or not
        if(choice2 == 0)
        {
            //label for brick pattern text
            jLabel23.setFont(new java.awt.Font("Tahoma", 0, 14));
            jLabel23.setText("BRICK PATTERN");
            newJFrame.getContentPane().add(jLabel23);
            jLabel23.setBounds(20, 390, 150, 20);
            //label for brick pattern details
            jLabel24.setFont(new java.awt.Font("Tahoma", 0, 14));
            jLabel24.setText("Patterns will be made into the wall/arches");
            newJFrame.getContentPane().add(jLabel24);
            jLabel24.setBounds(240, 390, 510, 20);
            //label for brick pattern cost
            jLabel25.setFont(new java.awt.Font("Tahoma", 0, 14));
            jLabel25.setText(fmt.format(brickCost *.05));
            newJFrame.getContentPane().add(jLabel25);
            jLabel25.setBounds(780, 390, 90, 20);
        }
        //label for subtotal cost
        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel22.setText(fmt.format(totalCost + (40*8*45)));
        newJFrame.getContentPane().add(jLabel22);
        jLabel22.setBounds(780, 440, 90, 20);
        //label for state tax text
        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel7.setText("STATE TAX (0.7%)");
        newJFrame.getContentPane().add(jLabel7);
        jLabel7.setBounds(640, 470, 120, 20);
        //label for sales tax cost
        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel20.setText(fmt.format(totalCost * .07));
        newJFrame.getContentPane().add(jLabel20);
        jLabel20.setBounds(780, 470, 90, 20);
        //label for final cost
        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 14));
        jLabel21.setText(fmt.format(totalCost += (totalCost * .07) + (40*8*45)));
        newJFrame.getContentPane().add(jLabel21);
        jLabel21.setBounds(780, 560, 90, 20);
        //uploads an invoice for background
        jLabel1.setIcon(new javax.swing.ImageIcon("resources/JavaSchoolBuilderInvoice.jpg"));
        newJFrame.getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 920, 710);
        
        // shows the JFrame and sets 
        newJFrame.pack();
        newJFrame.setVisible(true);
        newJFrame.setSize(915, 800);
        newJFrame.setLocation(500, 100);
    }
    
    
}
